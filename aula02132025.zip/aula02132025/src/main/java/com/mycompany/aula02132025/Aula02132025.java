
package com.mycompany.aula02132025;

import java.util.Scanner;

public class Aula02132025 {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);  // Create a Scanner object
        int opcao;
        System.out.println("Select the options below: ");
        System.out.println("\t [1] Adição (+)");
        System.out.println("\t [2] Subtraçâo (-)");
        System.out.println("\t [3] Multiplição (*)");
        System.out.println("\t [4] Divisão (/)");
        System.out.println("\t [0] Sair");
        
        
        
        
        opcao = scan.nextInt();
        
            if (scan = 1){
                int i = 0;
                i = scan + scan;
                System.out.println("A soma é" + i);
            } else if (scan = 2){
                int sub = 0;
                sub = scan - scan;
           } else if (num = 3){
               int mult = 0;
               mult = scan * scan;
                
        }
    }
        
    
}
